export class Task {
  status: number;
  desc: string;

}