import {Routes, RouterModule} from '@angular/router';
import {TaskComponent} from './task/task.component';
import {LoginComponent} from './app.component';
import {TeacherComponent} from './teacher/teacher.component';
import {CourseComponent} from './course/course.component';
import {CommunityComponent} from './community/community.component';
import {RoleComponent} from './role/role.component';
/*
 * Services
 */
import {AUTH_PROVIDERS} from './services/AuthService';
import {LoggedInGuard} from './guards/loggedIn.guard';

const appRoutes:Routes = [
  {
    path: '',
    component: TaskComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'task',
    component: TaskComponent
  },
  {
    path: 'teacher',
    component: TeacherComponent
  },
  {
    path: 'course',
    component: CourseComponent
  },
  {
    path: 'community',
    component: CommunityComponent
  },
  {
    path: 'role',
    component: RoleComponent
  },
  {
    path: '**',
    component: TaskComponent
  }
];
export const routing = RouterModule.forRoot(appRoutes);
