import { Component } from '@angular/core';
import { Input } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as $ from 'jquery';
/*
 * Services
 */
import {AuthService} from './services/AuthService';

@Component({
  selector: 'app-login',
  templateUrl: './login/login.component.html',
  styleUrls: ['./login/login.component.css',
        './app.component.css']
})
export class LoginComponent {

 message: string;

  constructor(private authService: AuthService, private http: HttpClient) {
    this.message = '';
  }

  login(username: string, password: string): boolean {
    this.message = '';
    if (!this.authService.login(username, password)) {
      this.message = 'Incorrect credentials.';
      setTimeout(function() {
        this.message = '';
      }.bind(this), 2500);
    }
    return false;
  }

  logout(): boolean {
    this.authService.logout();
    return false;
  }

}


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
    title = 'app';
    message = '';
    isLoggined = false;
    userRole = 1;
    url = 'http://edu.xk.com/xkapi';
    activeMenu = '';//todo
   // $('body').height($(window).height());
    login(user: string, password: string): any {
        let that = this;
        this.http.get(`${this.url}/login/login?name=${user}&password=${password}`).subscribe(
            result => {
                if(result) {
                  if (result['status'] == 200) {
                      let data = result['data'];
                      sessionStorage.setItem('username', user);
                      sessionStorage.setItem('role', data['role']);
                      that.userRole = data['role'];

                      console.log('activeMenu:' + this.activeMenu);
                      return true;
                  } else {
                      this.message = result['desc'];
                      return false;
                  }
              }
          }
      );    
    
  }

    logout(): void {
        sessionStorage.removeItem('username');
        sessionStorage.removeItem('role');
    }
    changeRoute(name) {
        this.activeMenu = name;
    }
    getUser(): any {
        return sessionStorage.getItem('username');
    }
    getRole(): any {
        return sessionStorage.getItem('role');
    }

  isLoggedIn(): boolean {
      console.log(`sessionStorage .getItem('username'):`+sessionStorage .getItem('username'));
      return this.getUser() !== null;
  }

  constructor(private authService: AuthService, private http: HttpClient) {
      this.message = '';
  }


  addArray=[];  
  xcood: any;  
  ycood: any;  
  
  additem(){  
    this.xcood = (document.getElementsByName('xcood')[0] as HTMLInputElement).value;  
    this.ycood = (document.getElementsByName('ycood')[0] as HTMLInputElement).value;  
    this.addArray.push({  
      xcood:this.xcood,  
      ycood:this.ycood  
    })  
  }  
}


export class NgbdDropdownBasic {
}

@Component({
  selector: 'demo-modal-static',
  styleUrls: ['./app.component.css'],
  templateUrl: './service-template.html'
})
export class DemoModalStaticComponent {
    onSubmit(userName: HTMLInputElement, pwd: HTMLInputElement):void {  
        console.log('form :'+ userName.value);
    }

}

@Component({  
  selector: 'data-table',  
  templateUrl: './dataTable-componen.html',  
  styleUrls: ['./app.component.css']  
})  
export class DataTableComponent {  
    @Input() array:any;//接收父组件传递过来的addArray数组  
    index: number;     //跟上面说的一样要先声明  
    delete(data){  
        this.index = this.array.indexOf(data);  
        if (this.index > -1) {  
            this.array.splice(this.index, 1);//跟上面说的一样在初始化的时候要用到this  
            }  
    } 
    edit (data) {  
        console.log('edit');
        document.getElementsByName('addTask')[0].style.display = 'block';
    } 
}  